# Capital & Conviction — Astro prototype

A mobile-responsive personal business and markets research blog, built with Astro and plain CSS. No paid libraries or APIs required.

## Start locally

1. Install Node.js 20.19+ or 22.12+.
2. In this folder, run `npm install`.
3. Run `npm run dev` and open the local URL displayed.
4. Run `npm run build` to generate the static site in `dist/`.

## Pages
- `/` — premium editorial homepage
- `/articles/` — working category filter and article listing
- `/articles/<slug>/` — four full sample articles, generated from `src/data/articles.js`
- `/research/` — working duration sensitivity calculator
- `/about/` — author introduction placeholder
- `/subscribe/` — newsletter coming-soon page

## Edit and publish

Edit the sample articles in `src/data/articles.js`. Each entry has a slug, category, date, title, summary, and content sections. Build and deploy again to publish.

## Deploy for free

1. Push this project to a GitHub repository.
2. In Cloudflare Pages, connect the repository.
3. Build command: `npm run build`.
4. Build output directory: `dist`.
5. Set `site` in `astro.config.mjs` to the final website URL.

## Before public launch

- Replace the author bio on `/about/` with your own details.
- Replace `hello@example.com` with a real contact address.
- Connect a proper opt-in newsletter provider; the prototype intentionally does **not** collect email addresses.
- Review and fact-check all sample article content and add source links for factual claims.
- Confirm your publication name and domain are available and not infringing others' trademarks.
- Add privacy and cookie notices as applicable and financial-disclosure policy.
- If you want a browser CMS, integrate Decap CMS with secure authentication; it is **not** wired into this prototype.
- The research calculator is illustrative only and does not use live market data.

## Design

Midnight Navy `#12243B`, Gold `#C9A45C`, Ivory `#F8F6F0`.
Typography: Newsreader (editorial), DM Sans (interface).
