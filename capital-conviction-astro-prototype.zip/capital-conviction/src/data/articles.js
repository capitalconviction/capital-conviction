export const articles = [
  {
    slug: 'when-growth-does-not-create-value', category: 'Business Deep Dives', date: '2026-10-14', minutes: 7,
    title: 'When Growth Does Not Create Value',
    dek: 'Revenue growth makes headlines. Returns on incremental capital tell a more revealing story.',
    featured: true,
    content: [
      {heading:'Growth is not the same as value creation', paragraphs:['A business can grow revenue rapidly while delivering disappointing shareholder outcomes. The missing link is often the amount of capital required to produce that growth, and the return earned on that capital.','Consider two hypothetical businesses. Each grows revenue by 15% annually. The first expands with modest reinvestment and resilient margins. The second requires substantial new assets and financing just to maintain its growth rate. Their economic outcomes can be very different.']},
      {heading:'Follow incremental returns', paragraphs:['Return on invested capital (ROIC) is a useful starting point, but investors should also ask what returns are being earned on the next rupee of reinvestment. If incremental returns are below the cost of capital, growth may destroy rather than create economic value.','Accounting conventions, acquisition effects, and business cycles can distort a single-year figure. Evaluate returns over time and compare them with cash generation.']},
      {heading:'The valuation connection', paragraphs:['Even excellent businesses can disappoint if their purchase price already assumes exceptional outcomes. Expectations embedded in valuation matter as much as operating performance.','A practical research process links three questions: how much can the business reinvest, at what incremental return, and what expectations are already reflected in the market price?']},
      {heading:'What to watch', paragraphs:['Monitor incremental ROIC, free-cash-flow conversion, working capital intensity, leverage, and management capital-allocation decisions. Use scenarios rather than a single point estimate.']}
    ]
  },
  {
    slug:'why-bond-prices-move-before-policy', category:'Markets & Fixed Income', date:'2026-10-10', minutes:6,
    title:'Why Bond Prices Move Before Policy Rates',
    dek:'Market expectations, term premiums and credit spreads can move well ahead of central-bank decisions.',
    content:[
      {heading:'Markets price the path, not just the next decision', paragraphs:['Bond yields reflect expectations for future short-term rates alongside term, liquidity, and credit risk premiums. Consequently, a change in market expectations can move bond prices before any policy announcement.']},
      {heading:'Duration translates yields into price sensitivity', paragraphs:['As a first-order approximation, a bond portfolio’s percentage price change is approximately negative modified duration multiplied by the yield change. For example, a portfolio with modified duration of 1.5 years would have an approximate 0.75% price gain from a 50-basis-point yield decline, before convexity, carry, expenses and spread changes. This is illustrative, not a forecast.']},
      {heading:'The credit-spread caveat', paragraphs:['Corporate and financial-sector bonds respond not only to sovereign yield changes but also to credit spreads and market liquidity. A fall in government yields does not guarantee an equal fall in corporate yields.']}
    ]
  },
  {
    slug:'innovation-and-the-investor', category:'Innovation & Strategy', date:'2026-10-06', minutes:5,
    title:'Innovation and the Investor’s Dilemma',
    dek:'Why product breakthroughs do not automatically translate into durable shareholder returns.',
    content:[
      {heading:'Innovation creates possibilities, not guarantees', paragraphs:['A successful new product can expand a market, but competitors, suppliers and customers may capture much of the economic benefit. The investor’s question is who retains the profits, for how long, and at what reinvestment cost.']},
      {heading:'Follow the economics', paragraphs:['Evaluate switching costs, distribution, intellectual property, pricing power and capital requirements. Then compare the market’s expectations with plausible operating scenarios.']}
    ]
  },
  {
    slug:'how-to-read-a-market-cycle', category:'Investment Research', date:'2026-10-01', minutes:5,
    title:'How to Read a Market Cycle Without Predicting the Top',
    dek:'A framework for combining valuations, earnings, liquidity and positioning without false precision.',
    content:[
      {heading:'A dashboard, not a crystal ball', paragraphs:['No single metric identifies market turning points consistently. Valuations, earnings revisions, liquidity conditions and investor positioning each illuminate different risks.']},
      {heading:'Translate signals into decisions', paragraphs:['Define ranges and scenarios before interpreting market moves. A disciplined process separates changes in fundamentals from changes in price and sentiment.']}
    ]
  }
];
export const categories = ['All', 'Business Deep Dives', 'Markets & Fixed Income', 'Innovation & Strategy', 'Investment Research'];
